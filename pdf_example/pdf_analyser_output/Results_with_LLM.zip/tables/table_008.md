| Dice | Precision | Recall | Volume Difference |
| --- | --- | --- | --- |
| 0.6126 ± 0.2577 | 0.6833 ± 0.2281 | 0.6385 ± 0.2963 | 6486 ± 9686 |
